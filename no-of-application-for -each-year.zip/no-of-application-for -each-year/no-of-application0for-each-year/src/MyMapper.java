//package sample;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class MyMapper extends Mapper<LongWritable,Text,IntWritable,Text>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String Value=inpv.toString();
		String eachVal[]=Value.split("\t");
		String casestatus=eachVal[1];
		
		int yr=Integer.parseInt( eachVal[7]);
		
		c.write(new IntWritable(yr),new Text(casestatus));
		
	}
	}